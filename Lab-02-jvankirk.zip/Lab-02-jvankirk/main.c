//
//  main.c
//  Lab-02-jvankirk
//
//  Created by Jaidyn Vankirk on 3/27/22.
//

#include <stdio.h>
#include <stdlib.h>

/*
 Linked List
 */

struct linked_list_node{
    int val;
    struct linked_list_node* next;
    struct linked_list_node* previous;
};

struct linked_list{
    struct linked_list_node* head;
    
};

/*
 Traverses the linked list and finds the node with the searched for integer(e).
 */
int search(int e, struct linked_list* ll){
    int ind = 0;    //Int ind. Location: stack
    struct linked_list_node* test = ll -> head; //Our test node starts at the beginning of the linked list.
    while(test != 0){    //It makes sure the node is not null.
        ind ++;     //Updates the index.
        if(test -> val == e){   //Tests to see if it is the element.
            return ind;     //If so it returns the index.
        }
        else {
            test = test -> next;    //If not, it moves on to the next node.
        }
    }
    return -1;  //If the while loop fails, it returns -1.
}

/*
 Traverses throught the linked list to find out the size.
 */
int getSize(struct linked_list* ll){
    int ind = 0;    //The index
    struct linked_list_node* test = ll -> head; //Starts at the head.
    while(test != 0){    //Checks to see if the node is null.
        test = test -> next;    //Then it moves to the next index.
        ind ++; //If not 0 or below, it increments the index.
        }
    return ind;     //Returns the index after the while loop fails.
}
/*
 This creates the element in the heap and inserts it in the list.
 */
void insert_element(int e, struct linked_list* ll){
    struct linked_list_node* n = malloc(sizeof(struct linked_list_node));   //First mallocs the new element.
    n -> val = e; //Assigns the value to the node.
    n -> next = 0;  //Assigns the address of the new node's next to null.
    struct linked_list_node* test = ll -> head; //Starts our test at the head of the list.
    if(getSize(ll) == 0){   //Uses get size to see if our list is empty.
        ll -> head = n;     //Assigns the new node as the head.
    } else {
        for(int i = 1; i < getSize(ll); i ++){  //If not the head, it uses the get size function to put the new node at the end of the list.
            test = test -> next;
        };
        test -> next = n;
        n -> previous = test;
    }
}

/*
 Uses search to find and remove an element from the linked list.
 */
void delete_element(int e, struct linked_list* ll){
    int ind = search(e, ll);    //Searches the list for the index.
    if(ind == 1){   //Uses this if the element being removed is the head.
        struct linked_list_node* remove_node = ll -> head;  //Gets the pointer on the current head.
        ll -> head = ll -> head -> next;    //Makes the next element the new head.
        if (ll -> head != 0){   //Checks to make sure the new head is not null.
            ll -> head -> previous = 0; //Sets the new heads previous to null.
        }
        free(remove_node);
    }else if (ind > 0){    //If it is not the head but still in the list, we use this.
        struct linked_list_node* current = ll -> head;  //Gets the head.
        for(int i = 0; i < ind-2; i++){ //Then traverses the list until we are one in front of the element.
            current = current -> next;
        }
        struct linked_list_node* remove_node = current -> next; //Gets the pointer to the element.
        current -> next = remove_node -> next; // Makes the element's next before the removed to point to the node after the removed.
        if(remove_node -> next != 0){   //Checks to make sure the node being removed is not the last node.
            remove_node -> next -> previous = current; // Updates the previous for current's next.
        }
        free(remove_node);
    }
}

/*
 Stack
 */

struct stack{
    int size;
    struct linked_list_node* top;
    struct linked_list* ll;
};

/*
 Creates the stack with an element the user has given.
 */
void create_stack(struct stack* s, int e, struct linked_list* ll){
    s -> size = 1;  //Makes the size 1.
    ll -> head = 0;  //In order to not have a null pointer exception.
    s->ll = ll;  //Gives the address of the linked list to the struct.
    insert_element(e, s->ll);   //Inserts the first element.
    s->top = s->ll->head;   //Makes this element the top.
};

/*
 Returns the value of the element at the top.
 */
int get_top(struct stack* s){
    return s->top->val;
};

/*
 Pops the element off of the top of the stack and increments the size.
 */
int pop_element(struct stack* s){
    int return_elem = get_top(s);  //Gets the top to return.
    delete_element(return_elem, s ->ll);    //Deletes the element from the list.
    s -> top = s->ll->head; //Makes the new head the top.
    s -> size = s -> size - 1;  //Increments the size.
    return return_elem;
}

/*
 Pushes elements onto the stack. This method inserts elements on to the list differently by inserting them at the head rather than the tail. This optimizes the priority queues run time.
 */
void push_element(struct stack* s, int e){
    s->size = s->size + 1;  //Updates the size
    
    struct linked_list_node* n = malloc(sizeof(struct linked_list_node));   //First mallocs the new element.
    n-> val = e;    //Assigns the new node the value
    n-> next = s -> ll-> head;   //Assigns its next as the original head
    if (s -> ll->head != 0){
        s-> ll->head->previous = n; //Makes the old head's previous the new node.
    }
    s -> ll->head = n;   //Makes the new node the head.
    s->top = s->ll->head;   //Makes the new node the top of the list.
}

/*
 Queue
 */
struct queue{
    int size;
    struct linked_list_node* top;
    struct linked_list_node* tail;
    struct linked_list* ll;
};

/*
 Creates the queue with the first element.
 */
void create_queue(struct queue* q, int e, struct linked_list* ll){
    q -> size = 1;  //Makes the size 1
    q -> ll = ll;   //Connects the linked list in the main to the queue.
    insert_element(e, ll);  //Inserts the element and makes it both the tail and top.
    q->tail = ll -> head;
    q->top = ll -> head;
}

/*
 Returns the value of the top of the queue.
 */
int get_top_queue(struct queue* q){
    return q -> top -> val;
}

/*
 Pops the element off of the top end.
 */
int pop_element_queue(struct queue* q){
    int return_elem = get_top_queue(q);  //Gets the top to return.
    delete_element(return_elem, q ->ll);    //Deletes the element from the list.
    q -> top = q -> ll -> head;
    q -> size = q -> size - 1;  //Increments the size.
    return return_elem;
}

/*
 Pushes the new element on to the queue by adding using the linked list insert_element method.
 */
void push_element_queue(struct queue* q, int e){
    insert_element(e, q->ll);
    q -> tail = q -> tail -> next;  //Updates the tail
    if(q->size == 0){   //Checks to see if the queue is empty. If so it makes the new element the top and the tail.
        q-> top = q-> ll -> head;
        q-> tail = q-> ll -> head;
    };
    q -> size = q -> size + 1;  //Increments the size.
}


int main(int argc, const char * argv[]) {
    /*
     These are test that I have created for each of the data structures. Feeback is given in the console.
    */
    
    /*
     Linked List
     */
    struct linked_list ll;
    ll.head = 0;
    struct linked_list* p_ll = &ll;
    insert_element(15, p_ll);
    insert_element(20, p_ll);
    insert_element(25, p_ll);
    
    printf("I added the values 15, 20, and 25. The index of 15 is %d. The index of 20 is %d. The index of 25 is %d.\n I searched for 40 in the array and it returned %d.\n The size of the linked list is %d.\n" , search(15, p_ll), search(20, p_ll), search(25, p_ll), search(40, p_ll), getSize(p_ll));
    
    delete_element(20, p_ll);
    
    printf("I deleted 20. The index of 20 is %d.\n", search(20,p_ll));
    
    delete_element(25, p_ll);
    
    printf("I deleted 25. The index of 25 is %d.\n", search(25,p_ll));
    
    insert_element(30, p_ll);
    
    printf("I added 30. The index of 30 is %d.\n", (search(30, p_ll)));
    
    insert_element(35, p_ll);
    
    delete_element(15, p_ll);
    
    printf("I deleted 15 from the linked list. The index of 30 is %d. I also inserted the element 35. The index of 35 is %d.\n", search(30,p_ll), search(35, p_ll));
    
    printf("\n");   //To seperate the next section.
    
    /*
     Linked List
     */
    
    struct stack s;
    struct stack* p_s = &s;
    struct linked_list link;
    struct linked_list* p_link = & link;
    create_stack(p_s, 5, p_link);
    int size = p_s -> size;
    int top = get_top(p_s);
    printf("I added 5 to the stack. The current size is %d. The top is %d.\n", size, top);
    
    printf("I popped %d off of the stack. The current size is %d.\n", pop_element(p_s), p_s -> size);
    
    push_element(p_s, 10);
    printf("I added 10 to the stack. The current size is %d. The top is %d.\n", p_s -> size, get_top(p_s));
    
    push_element(p_s, 15);
    push_element(p_s, 20);
    push_element(p_s, 25);
    printf("I added 15, 20, and 25 to the stack. The current size is %d. The top is %d.\n", p_s -> size, get_top(p_s));
    
    printf("I popped %d off of the stack. The current size is %d. The top is %d.\n", pop_element(p_s), p_s -> size, get_top(p_s));
    
    printf("\n"); //To make the console easier to read.
    
    /*
     Queue
     */
    struct queue q;
    struct queue* p_q = &q;
    struct linked_list linked;
    struct linked_list* p_linked = &linked;
    create_queue(p_q, 5, p_linked);
    printf("I added 5 to the queue. The top element is %d.\n", get_top_queue(p_q));
    
    printf("I popped %d off the queue. The size is %d.\n", pop_element_queue(p_q), p_q -> size);
    
    push_element_queue(p_q, 10);
    
    printf("I pushed 10 on to the queue. The top element is %d. The size is %d.\n", get_top_queue(p_q), p_q -> size);
    
    push_element_queue(p_q, 15);
    push_element_queue(p_q, 20);
    push_element_queue(p_q, 25);
    
    printf("I pushed 15, 20, and 25 on to the queue. The top element is %d. The size is %d.\n", get_top_queue(p_q), p_q -> size);
    
    printf("I popped %d off the queue. The size is %d. The top is now %d.\n", pop_element_queue(p_q), p_q -> size, get_top_queue(p_q));
    
    printf("I popped %d off the queue. The size is %d. The top is now %d.\n", pop_element_queue(p_q), p_q -> size, get_top_queue(p_q));
    printf("I popped %d off the queue. The size is %d. The top is now %d.\n", pop_element_queue(p_q), p_q -> size, get_top_queue(p_q));
    
    return 0;
    
/*
 (test)
 */
}
